*******
Authors
*******

Development Lead
================

- Steven Loria <sloria1@gmail.com> `@sloria <https://github.com/sloria>`_

Contributors (chronological)
============================

- Pete Keen `@peterkeen <https://github.com/peterkeen>`_
- Matthew Honnibal `@syllog1sm <https://github.com/syllog1sm>`_
- Roman Yankovsky `@RomanYankovsky <https://github.com/RomanYankovsky>`_
- David Karesh `@davidnk <https://github.com/davidnk>`_
- Evan Dempsey `@evandempsey <https://github.com/evandempsey>`_
- Wesley Childs `@mrchilds <https://github.com/mrchilds>`_
- Jeff Schnurr `@jschnurr <https://github.com/jschnurr>`_
